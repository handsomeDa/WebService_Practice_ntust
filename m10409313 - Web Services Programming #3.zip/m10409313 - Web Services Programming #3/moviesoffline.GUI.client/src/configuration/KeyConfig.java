package configuration;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class KeyConfig {
	private String AES_KEY;
	private String PRIVATE_KEY_A;
	private String PUBLIC_KEY_B;
	
	public KeyConfig(){
		super();
		
		Properties configuration;
		try {
			configuration = new Properties();
			InputStream stream = this.getClass().getResourceAsStream("/configuration/config.properties");
			configuration.load(stream);
			AES_KEY = configuration.getProperty("AES_KEY");
			PRIVATE_KEY_A = configuration.getProperty("PRIVATE_KEY_A");
			PUBLIC_KEY_B = configuration.getProperty("PUBLIC_KEY_B");
		} catch (IOException iex) {
			iex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public String getAES_KEY() {
		return AES_KEY;
	}
	public void setAES_KEY(String AES_KEY) {
		this.AES_KEY = AES_KEY;
	}
	
	public String getPRIVATE_KEY_A() {
		return PRIVATE_KEY_A;
	}
	public void setPRIVATE_KEY_A(String PRIVATE_KEY_A) {
		this.PRIVATE_KEY_A = PRIVATE_KEY_A;
	}
	
	public String getPUBLIC_KEY_B() {
		return PUBLIC_KEY_B;
	}
	public void setPUBLIC_KEY_B(String PUBLIC_KEY_B) {
		this.PUBLIC_KEY_B = PUBLIC_KEY_B;
	}
}
