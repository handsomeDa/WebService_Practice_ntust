package moviesoffline.GUI.client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.ws.rs.core.MediaType;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.net.URI;
import java.security.Key;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Arrays;
import java.util.Base64;
import java.awt.event.ActionEvent;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;
import javax.xml.bind.DatatypeConverter;

import org.glassfish.jersey.client.ClientConfig;

import configuration.KeyConfig;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class clientUse {
	JButton btnLogin = new JButton("Log in");
	JButton btnNewButton = new JButton("Log out");
	JButton btnInsert = new JButton("Insert-Movie-to-Watch-List");
	JButton btnSelfwatchlist = new JButton("Self-Watch-List");
	JComboBox comboBox = new JComboBox();
	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	ClientConfig config = new ClientConfig();
	Client client = ClientBuilder.newClient(config);
	WebTarget targetService = client.target(getBaseURI());
	String plainAnswer;
	String serverAnswer;
	String userID;
	String keyStr;
	String ALGO = "AES";
	static String location = System.getProperty("user.dir");
	private JTextField textField_1;
	private JTextField textField_3;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					clientUse window = new clientUse();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void getAES_KEY() {
		KeyConfig kc = new KeyConfig();
		keyStr = kc.getAES_KEY();
	}

	public Key generateKey() throws Exception {
		byte[] keyValue = keyStr.getBytes("UTF-8");
		MessageDigest sha = MessageDigest.getInstance("SHA-1");
		keyValue = sha.digest(keyValue);
		keyValue = Arrays.copyOf(keyValue, 16); // use only first 128 bit
		Key key = new SecretKeySpec(keyValue, ALGO);
		return key;
	}

	public String encrypt(String Data) throws Exception {
		Key key = generateKey();
		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.ENCRYPT_MODE, key);
		byte[] encVal = c.doFinal(Data.getBytes());
		String encryptedValue = DatatypeConverter.printBase64Binary(encVal);
		return encryptedValue;
	}

	public String decrypt(String encryptedData) throws Exception {
		Key key = generateKey();
		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.DECRYPT_MODE, key);
		byte[] decordedValue = DatatypeConverter.parseBase64Binary(encryptedData);
		byte[] decValue = c.doFinal(decordedValue);
		String decryptedValue = new String(decValue);
		return decryptedValue;
	}
	
	public static void Signature_Process() {
		try {
			// Signature Process
			// call getInstance() get Signature entity
			Signature signature = Signature.getInstance("DSA");
			ObjectInputStream is = new ObjectInputStream(new FileInputStream(location + "\\privateA.key"));
			PrivateKey priKey = (PrivateKey) is.readObject();
			// call initSign() initial Signature
			signature.initSign(priKey);
			is.close();
			System.out.println(priKey);
			// call sign() get Signature
			FileOutputStream out = new FileOutputStream(location + "\\signA.key");
			byte[] raw = signature.sign();
			out.write(raw); // write the signature
			out.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static void Verification_Process() {
		try {
			// Verification Process
			// call getInstance() get Signature entity
			Signature signature1 = Signature.getInstance("DSA");
			// call initVerify() initial Signature
			ObjectInputStream is1 = new ObjectInputStream(new FileInputStream(location + "\\publicB.key"));
			PublicKey puKey = (PublicKey) is1.readObject();
			signature1.initVerify(puKey);
			is1.close();
			System.out.println(puKey);
			// call verify() get Verification
			FileInputStream sigIn = new FileInputStream(location + "\\signB.key");
			byte[] raw1 = new byte[sigIn.available()];
			sigIn.read(raw1);
			sigIn.close();
			if (signature1.verify(raw1)) {
				// verification success
				System.out.println("The signature is good."); 
				//return "ok";
			} else {
				// verification fail
				System.out.println("The signature is bad."); 
				//return "no";
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private static URI getBaseURI() {

		return UriBuilder.fromUri("http://localhost:8080/moviesoffline").build();
	}

	/**
	 * Create the application.
	 */
	public clientUse() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frame = new JFrame();
		frame.setBounds(100, 100, 455, 220);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(10, 10, 61, 15);
		frame.getContentPane().add(lblUsername);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(10, 32, 61, 15);
		frame.getContentPane().add(lblPassword);

		textField = new JTextField();
		textField.setBounds(86, 7, 130, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String input1 = textField.getText();
				String input2 = passwordField.getText();
				
				//C2S
				//get AES_KEY
				getAES_KEY();
				try {
					//encryption AES
					String encodeData = encrypt(input1 + "_" + input2);
					//base64 Form URI
					if (encodeData.indexOf("+") != -1 || encodeData.indexOf("/") != -1) {
						String FormInfoValue = encodeData.replace("/", "-");
						encodeData = FormInfoValue.replace("+", "!");
					}
					
					//Signature
					Signature_Process();
					
					//System.out.println(location);
					plainAnswer = targetService.path("m10409313").path("/login/list/" + encodeData).request()
							.accept(MediaType.APPLICATION_JSON).get(String.class);
					
					if(encodeData != null){
						Verification_Process();
					}
					
					serverAnswer = decrypt(plainAnswer);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String aa = "[]";
				if (serverAnswer.equals(aa)) {
					JOptionPane.showMessageDialog(null, "Username or Password is Error!");
				} else {
					String infoValue3 = serverAnswer.replace("[{\"user_id\":\"", "");
					userID = infoValue3.replace("\"}]", "");
					JOptionPane.showMessageDialog(null, "Hello~ USER: " + userID);
					textField_1.setEnabled(true);
					comboBox.setEnabled(true);
					textField_3.setEnabled(true);
					btnInsert.setEnabled(true);
					btnSelfwatchlist.setEnabled(true);
					btnNewButton.setEnabled(true);
					btnLogin.setEnabled(false);
				}
			}
		});
		btnLogin.setBounds(226, 10, 96, 37);
		frame.getContentPane().add(btnLogin);

		passwordField = new JPasswordField();
		passwordField.setBounds(86, 29, 130, 21);
		frame.getContentPane().add(passwordField);
		btnSelfwatchlist.setEnabled(false);

		
		btnSelfwatchlist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//Signature
				Signature_Process();
				
				//C2S
				//get AES_KEY
				getAES_KEY();
				String encodeData;
				try {
					//encryption AES
					encodeData = encrypt(userID);
					//base64 Form URI
					if (encodeData.indexOf("+") != -1 || encodeData.indexOf("/") != -1) {
						String FormInfoValue = encodeData.replace("/", "-");
						encodeData = FormInfoValue.replace("+", "!");
					}
					plainAnswer = targetService.path("m10409313").path("/watch/list/" + encodeData).request()
							.accept(MediaType.APPLICATION_JSON).get(String.class);
					
					if(encodeData != null){
						Verification_Process();
					}
					
					serverAnswer = decrypt(plainAnswer);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				

				String dd = "[]";
				if (serverAnswer.equals(dd)) {
					JOptionPane.showMessageDialog(null, "No Watchlist!");
				} else {
					String wt1 = serverAnswer.replace("[{", "");
					String wt2 = wt1.replace("},{", "\n");
					String wt3 = wt2.replace("}]", "");
					JOptionPane.showMessageDialog(null, "\n/*All-Self-Watch-List*/\n" + wt3 + "\n/*END*/\n");
				}
			}
		});
		btnSelfwatchlist.setBounds(226, 57, 208, 33);
		frame.getContentPane().add(btnSelfwatchlist);
		
		
		btnNewButton.setEnabled(false);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				userID = null;
				textField.setText("");
				passwordField.setText("");
				textField_1.setText("");
				textField_3.setText("");
				textField_1.setEnabled(false);
				comboBox.setEnabled(false);
				textField_3.setEnabled(false);
				btnInsert.setEnabled(false);
				btnSelfwatchlist.setEnabled(false);
				btnNewButton.setEnabled(false);
				btnLogin.setEnabled(true);
				JOptionPane.showMessageDialog(null, "You alredy log out!");
			}
		});
		btnNewButton.setBounds(332, 10, 102, 37);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblMovieId = new JLabel("Movie ID");
		lblMovieId.setBounds(10, 104, 104, 15);
		frame.getContentPane().add(lblMovieId);
		
		JLabel lblMovieStatus = new JLabel("Movie Status");
		lblMovieStatus.setBounds(10, 129, 104, 15);
		frame.getContentPane().add(lblMovieStatus);
		
		JLabel lblMovieModifieddate = new JLabel("Movie ModifiedDate");
		lblMovieModifieddate.setBounds(10, 154, 130, 15);
		frame.getContentPane().add(lblMovieModifieddate);
		
		textField_1 = new JTextField();
		textField_1.setEnabled(false);
		textField_1.setBounds(120, 101, 96, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setEnabled(false);
		textField_3.setBounds(120, 151, 96, 21);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		
		comboBox.setEnabled(false);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"watch list", "watched", "deleted"}));
		comboBox.setBounds(120, 126, 96, 21);
		frame.getContentPane().add(comboBox);
		btnInsert.setEnabled(false);
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String str1 = textField_1.getText();
				String str2 = comboBox.getSelectedItem().toString();
				String str3 = textField_3.getText();
				
				if (str3.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
					JOptionPane.showMessageDialog(null, "Movie ModifiedDate FORM OK!\n(e.g. 1992-10-30)");
					System.out.println("Form OK.");
				} else {
					JOptionPane.showMessageDialog(null, "Movie ModifiedDate FORM ERROR!\n(e.g. 1992-10-30)");
					System.out.println("Form Error.");
				}
				
				String value = userID + "_" + str1 + "_" + str2 + "_" + str3;
				
				//Signature
				Signature_Process();
				
				//C2S
				//get AES_KEY
				getAES_KEY();
				String encodeData;
				try {
					//encryption AES
					encodeData = encrypt(value);
					//base64 Form URI
					if (encodeData.indexOf("+") != -1 || encodeData.indexOf("/") != -1) {
						String FormInfoValue = encodeData.replace("/", "-");
						encodeData = FormInfoValue.replace("+", "!");
					}
					
					plainAnswer = targetService.path("m10409313").path("/insert/list/" + encodeData).request()
							.accept(MediaType.APPLICATION_JSON).get(String.class);
					
					if(encodeData != null){
						Verification_Process();
					}
					
					serverAnswer = decrypt(plainAnswer);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}			
				
				String ee = "[]";
				if (serverAnswer.equals(ee)) {
					JOptionPane.showMessageDialog(null, "No Movies!");
					System.out.println("No Movies!");
				} else {
					String it1 = serverAnswer.replace("[{", "");
					String it2 = it1.replace("},{", "\n");
					String it3 = it2.replace("}]", "");
					JOptionPane.showMessageDialog(null, "\n/*All-Self-Watch-List*/\n" + it3 + "\n/*END*/\n");
				}
			}
		});
		btnInsert.setBounds(10, 57, 208, 33);
		frame.getContentPane().add(btnInsert);
	}
}
