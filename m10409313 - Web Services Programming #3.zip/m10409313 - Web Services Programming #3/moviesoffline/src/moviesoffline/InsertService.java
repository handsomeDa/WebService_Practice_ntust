package moviesoffline;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.security.Key;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.ArrayList;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.DatatypeConverter;

import com.google.gson.Gson;

import configuration.DbConfig;
import dto.Insert;
import model.InsertManager;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

@Path("/insert")
public class InsertService {
	String keyStr;
	String ALGO = "AES";
	static String location = System.getProperty("user.dir");

	// http://localhost:8080/moviesoffline/m10409313/insert/list/{inputURI}
	@GET
	@Path("/list/{inputURI}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllInsertData(@PathParam("inputURI") String encodeData) throws Exception {
		if (encodeData != null) {
			Verification_Process();
		}

		// C2S
		// get AES_KEY
		getAES_KEY();
		// base64 Form URI
		String a1 = encodeData;
		if (a1.indexOf("!") != -1 || a1.indexOf("-") != -1) {
			String FormInfoValue = a1.replace("-", "/");
			a1 = FormInfoValue.replace("!", "+");
		}
		// decryption AES
		String insertInfo = decrypt(a1);

		String[] infoValue = insertInfo.split("_");
		String userID = infoValue[0];
		String mm = infoValue[1];
		String ss = infoValue[2];
		String dd = infoValue[3];
		String listInsertData = null;
		Gson gson = new Gson();

		ArrayList<Insert> listInsert = new ArrayList<Insert>();
		InsertManager insertManager = new InsertManager();

		listInsert = insertManager.getAllInsert(userID, mm, ss, dd);
		listInsertData = gson.toJson(listInsert);

		// S2C
		// get AES_KEY
		getAES_KEY();
		String encodeData2 = encrypt(listInsertData);
		Signature_Process();

		return encodeData2;
	}

	public void getAES_KEY() {
		DbConfig kc = new DbConfig();
		keyStr = kc.getAES_KEY();
	}

	public Key generateKey() throws Exception {
		byte[] keyValue = keyStr.getBytes("UTF-8");
		MessageDigest sha = MessageDigest.getInstance("SHA-1");
		keyValue = sha.digest(keyValue);
		keyValue = Arrays.copyOf(keyValue, 16); // use only first 128 bit
		Key key = new SecretKeySpec(keyValue, ALGO);
		return key;
	}

	public String encrypt(String Data) throws Exception {
		Key key = generateKey();
		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.ENCRYPT_MODE, key);
		byte[] encVal = c.doFinal(Data.getBytes());
		String encryptedValue = DatatypeConverter.printBase64Binary(encVal);
		return encryptedValue;
	}

	public String decrypt(String encryptedData) throws Exception {
		Key key = generateKey();
		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.DECRYPT_MODE, key);
		byte[] decordedValue = DatatypeConverter.parseBase64Binary(encryptedData);
		byte[] decValue = c.doFinal(decordedValue);
		String decryptedValue = new String(decValue);
		return decryptedValue;
	}

	public static void Verification_Process() {
		try {
			// Verification Process
			// call getInstance() get Signature entity
			Signature signature1 = Signature.getInstance("DSA");
			// call initVerify() initial Signature
			ObjectInputStream is1 = new ObjectInputStream(new FileInputStream(location + "\\publicA.key"));
			PublicKey puKey = (PublicKey) is1.readObject();
			signature1.initVerify(puKey);
			is1.close();
			System.out.println(puKey);
			// call verify() get Verification
			FileInputStream sigIn = new FileInputStream(location + "\\signA.key");
			byte[] raw1 = new byte[sigIn.available()];
			sigIn.read(raw1);
			sigIn.close();
			if (signature1.verify(raw1)) {
				// verification success
				System.out.println("The signature is good.");
				// return "ok";
			} else {
				// verification fail
				System.out.println("The signature is bad.");
				// return "no";
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static void Signature_Process() {
		try {
			// Signature Process
			// call getInstance() get Signature entity
			Signature signature = Signature.getInstance("DSA");
			ObjectInputStream is = new ObjectInputStream(new FileInputStream(location + "\\privateB.key"));
			PrivateKey priKey = (PrivateKey) is.readObject();
			// call initSign() initial Signature
			signature.initSign(priKey);
			is.close();
			System.out.println(priKey);
			// call sign() get Signature
			FileOutputStream out = new FileOutputStream(location + "\\signB.key");
			byte[] raw = signature.sign();
			out.write(raw); // write the signature
			out.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
