package moviesoffline;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;

import dto.Movie;
import model.MovieManager;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

@Path("/moviesAll")
public class MovieService {
	//http://localhost:8080/moviesoffline/m10409313/moviesAll/list
		@GET
		@Path("/list")
		@Produces(MediaType.APPLICATION_JSON)
		public String getAllMovieData() {
			String listMovieData = null;
			Gson gson = new Gson();
			
			ArrayList<Movie> listMovie = new ArrayList<Movie>();
			MovieManager movieManager = new MovieManager();

			listMovie = movieManager.getAllMovie();
			listMovieData = gson.toJson(listMovie);
			
			return listMovieData;
		}
}
