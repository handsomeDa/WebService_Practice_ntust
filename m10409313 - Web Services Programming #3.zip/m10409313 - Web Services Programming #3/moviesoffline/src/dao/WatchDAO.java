package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.PreparedStatement;

import configuration.DbConfig;
import dto.Watch;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class WatchDAO {
	public ArrayList<Watch> getAllWatchs(DbConfig dbLink, String userID) {
		ArrayList<Watch> watchData = new ArrayList<Watch>();

		try {
			String sql = "";
			// start the connection first
			dbLink.StartConnection();
			
			sql = "SELECT * FROM `watchlist` "
					+ "WHERE `user_id` = '" + userID+"'";
			PreparedStatement ps = (PreparedStatement) dbLink.getDbConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Watch tmpWatch = new Watch();
				tmpWatch.setUser_id(rs.getString("user_id"));
				tmpWatch.setMovie_id(rs.getString("movie_id"));
				tmpWatch.setStatus(rs.getString("status"));
				tmpWatch.setModifiedDate(rs.getString("modifiedDate"));
				
				watchData.add(tmpWatch);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbLink.StopConnection();
		}
		
		return watchData;
	}
}
