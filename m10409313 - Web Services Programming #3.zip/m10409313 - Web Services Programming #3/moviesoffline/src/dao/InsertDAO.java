package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.PreparedStatement;

import configuration.DbConfig;
import dto.Insert;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class InsertDAO {
	public ArrayList<Insert> getAllInserts(DbConfig dbLink, String userID, String mm, String ss, String dd) {
		ArrayList<Insert> insertData = new ArrayList<Insert>();

		try {
			String sql = "";
			// start the connection first
			dbLink.StartConnection();
			
			sql = "SELECT * FROM `watchlist` "
							+ "WHERE `user_id` = '" + userID+"'";
			
			PreparedStatement ps = (PreparedStatement) dbLink.getDbConnection().prepareStatement(sql);
			
			ps.executeUpdate("INSERT INTO `watchlist`(`user_id`, `movie_id`, `status`, `modifiedDate`) "
					+ "VALUES ('"+userID+"', '"+mm+"', '"+ss+"', '"+dd+"')");
			
			ResultSet rs = ps.executeQuery();			
			
			while (rs.next()) {
				Insert tmpInsert = new Insert();
				tmpInsert.setUser_id(rs.getString("user_id"));
				tmpInsert.setMovie_id(rs.getString("movie_id"));
				tmpInsert.setStatus(rs.getString("status"));
				tmpInsert.setModifiedDate(rs.getString("modifiedDate"));
				
				insertData.add(tmpInsert);
			}			
			
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbLink.StopConnection();
		}
		
		return insertData;
	}
}
