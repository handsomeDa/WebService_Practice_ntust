package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.PreparedStatement;

import configuration.DbConfig;
import dto.Movie;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class MovieDAO {
	public ArrayList<Movie> getAllMovies(DbConfig dbLink) {
		ArrayList<Movie> movieData = new ArrayList<Movie>();

		try {
			String sql = "";
			// start the connection first
			dbLink.StartConnection();
			
			sql = "SELECT * FROM movie ";
			PreparedStatement ps = (PreparedStatement) dbLink.getDbConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Movie tmpMovie = new Movie();
				tmpMovie.setMovie_id(rs.getString("movie_id"));
				tmpMovie.setTitle(rs.getString("title"));
				tmpMovie.setGenre_id(rs.getString("genre_id"));
				tmpMovie.setAge_rating(rs.getString("age_rating"));
				tmpMovie.setReleaseDate(rs.getString("releaseDate"));
				tmpMovie.setStoryline(rs.getString("storyline"));
				
				movieData.add(tmpMovie);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbLink.StopConnection();
		}
		
		return movieData;
	}
}
