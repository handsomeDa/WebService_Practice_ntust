package model;

import java.util.ArrayList;

import configuration.DbConfig;
import dao.AccountDAO;
import dto.Account;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class AccountManager {
	public ArrayList<Account> getAllAccount(String accountStr, String passwordStr) {
		ArrayList<Account> listAccount = new ArrayList<Account>();
		DbConfig dbLink;
		try {
			dbLink = new DbConfig();
			
			AccountDAO accountAccessObject = new AccountDAO();
			listAccount = accountAccessObject.getAllAccounts(dbLink, accountStr, passwordStr);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listAccount;
	}
}