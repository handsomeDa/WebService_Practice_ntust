package model;

import java.util.ArrayList;

import configuration.DbConfig;
import dao.WatchDAO;
import dto.Watch;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class WatchManager {
	public ArrayList<Watch> getAllWatch(String userID) {
		ArrayList<Watch> listWatch = new ArrayList<Watch>();
		DbConfig dbLink;
		try {
			dbLink = new DbConfig();
			
			WatchDAO watchAccessObject = new WatchDAO();
			listWatch = watchAccessObject.getAllWatchs(dbLink, userID);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listWatch;
	}
}
