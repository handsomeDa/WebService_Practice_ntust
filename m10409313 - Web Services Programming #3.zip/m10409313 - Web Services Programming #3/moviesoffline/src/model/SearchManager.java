package model;

import java.util.ArrayList;

import configuration.DbConfig;
import dao.SearchDAO;
import dto.Search;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class SearchManager {
	public ArrayList<Search> getAllMovie(String searchInfo) {
		ArrayList<Search> listSearch = new ArrayList<Search>();
		DbConfig dbLink;
		try {
			dbLink = new DbConfig();
			
			SearchDAO searchAccessObject = new SearchDAO();
			listSearch = searchAccessObject.getAllSearchs(dbLink, searchInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listSearch;
	}
}
