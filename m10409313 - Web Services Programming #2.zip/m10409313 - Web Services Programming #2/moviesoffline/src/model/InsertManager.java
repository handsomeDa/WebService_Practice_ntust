package model;

import java.util.ArrayList;

import configuration.DbConfig;
import dao.InsertDAO;
import dto.Insert;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class InsertManager {
	public ArrayList<Insert> getAllInsert(String userID, String mm, String ss, String dd) {
		ArrayList<Insert> listInsert = new ArrayList<Insert>();
		DbConfig dbLink;
		try {
			dbLink = new DbConfig();
			
			InsertDAO insertAccessObject = new InsertDAO();
			listInsert = insertAccessObject.getAllInserts(dbLink, userID, mm, ss, dd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listInsert;
	}
}
