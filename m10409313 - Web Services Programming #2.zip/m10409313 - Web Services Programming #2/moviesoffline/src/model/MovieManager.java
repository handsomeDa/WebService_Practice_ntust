package model;

import java.util.ArrayList;

import configuration.DbConfig;
import dao.MovieDAO;
import dto.Movie;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class MovieManager {
	public ArrayList<Movie> getAllMovie() {
		ArrayList<Movie> listMovie = new ArrayList<Movie>();
		DbConfig dbLink;
		try {
			dbLink = new DbConfig();
			
			MovieDAO movieAccessObject = new MovieDAO();
			listMovie = movieAccessObject.getAllMovies(dbLink);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listMovie;
	}
}
