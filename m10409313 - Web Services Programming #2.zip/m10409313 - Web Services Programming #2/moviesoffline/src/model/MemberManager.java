package model;

import java.util.ArrayList;

import configuration.DbConfig;
import dao.MemberDAO;
import dto.Member;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class MemberManager {
	public ArrayList<Member> getAllMember(String nameL) {
		ArrayList<Member> listMember = new ArrayList<Member>();
		DbConfig dbLink;
		try {
			dbLink = new DbConfig();
			
			MemberDAO memberAccessObject = new MemberDAO();
			listMember = memberAccessObject.getAllMembers(dbLink, nameL);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listMember;
	}
}