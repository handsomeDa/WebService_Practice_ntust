package dto;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class Watch {
	private String user_id;
	private String movie_id;
	private String status;
	private String modifiedDate;
	
	public Watch(){
		super();
		
		//username = "";
		//password = "";
	}
	
	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getMovie_id() {
		return movie_id;
	}

	public void setMovie_id(String movie_id) {
		this.movie_id = movie_id;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
