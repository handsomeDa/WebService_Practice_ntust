package moviesoffline;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;

import dto.Account;
import model.AccountManager;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

@Path("/login")
public class AccountLoginService {
	
	//http://localhost:8080/moviesoffline/m10409313/login/list/{inputURI}
		@GET
		@Path("/list/{inputURI}")
		@Produces(MediaType.APPLICATION_JSON)
		public String getAllAccountData(@PathParam("inputURI") String loginInfo) {
			String[] infoValue = loginInfo.split("_");
			
			String accountStr = infoValue[0];
			String passwordStr = infoValue[1];
			String listAccountData = null;
			Gson gson = new Gson();
			
			ArrayList<Account> listAccount = new ArrayList<Account>();
			AccountManager accountManager = new AccountManager();

			listAccount = accountManager.getAllAccount(accountStr, passwordStr);
			listAccountData = gson.toJson(listAccount);
			
			return listAccountData;			 
		}
}
