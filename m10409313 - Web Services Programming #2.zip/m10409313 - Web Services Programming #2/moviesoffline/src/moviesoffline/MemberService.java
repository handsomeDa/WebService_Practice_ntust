package moviesoffline;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;

import dto.Member;
import model.MemberManager;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

@Path("/movies")
public class MemberService {
	
	//http://localhost:8080/moviesoffline/m10409313/movies/list/{inputURI}
	@GET
	@Path("/list/{inputURI}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllMemberData(@PathParam("inputURI") String nameL) {
		String listMemberData = null;
		Gson gson = new Gson();
		
		ArrayList<Member> listMember = new ArrayList<Member>();
		MemberManager memberManager = new MemberManager();

		listMember = memberManager.getAllMember(nameL);
		listMemberData = gson.toJson(listMember);
		
		return listMemberData;
	}
	
	@GET
	@Path("/login/{inputURI}")
	@Produces(MediaType.TEXT_PLAIN)	
	public String celciusT(@PathParam("inputURI") String loginData){
		String userAccount = loginData;
		
		return "ok";
	}
}