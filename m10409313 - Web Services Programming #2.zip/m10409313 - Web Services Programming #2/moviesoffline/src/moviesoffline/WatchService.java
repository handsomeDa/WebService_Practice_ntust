package moviesoffline;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;

import dto.Watch;
import model.WatchManager;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

@Path("/watch")
public class WatchService {
	//http://localhost:8080/moviesoffline/m10409313/watch/list/{inputURI}
		@GET
		@Path("/list/{inputURI}")
		@Produces(MediaType.APPLICATION_JSON)
		public String getAllWatchData(@PathParam("inputURI") String userID) {
			String listWatchData = null;
			Gson gson = new Gson();
			
			ArrayList<Watch> listWatch = new ArrayList<Watch>();
			WatchManager watchManager = new WatchManager();

			listWatch = watchManager.getAllWatch(userID);
			listWatchData = gson.toJson(listWatch);
			
			return listWatchData;
		}
}
