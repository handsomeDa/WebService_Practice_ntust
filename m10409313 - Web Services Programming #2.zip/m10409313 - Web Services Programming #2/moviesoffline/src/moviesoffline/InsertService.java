package moviesoffline;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;

import dto.Insert;
import model.InsertManager;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

@Path("/insert")
public class InsertService {
	//http://localhost:8080/moviesoffline/m10409313/insert/list/{inputURI}
			@GET
			@Path("/list/{inputURI}")
			@Produces(MediaType.APPLICATION_JSON)
			public String getAllInsertData(@PathParam("inputURI") String insertInfo) {
				String[] infoValue = insertInfo.split("_");
				String userID = infoValue[0];
				String mm = infoValue[1];
				String ss = infoValue[2];
				String dd = infoValue[3];
				String listInsertData = null;
				Gson gson = new Gson();
				
				ArrayList<Insert> listInsert = new ArrayList<Insert>();
				InsertManager insertManager = new InsertManager();

				listInsert = insertManager.getAllInsert(userID, mm, ss, dd);
				listInsertData = gson.toJson(listInsert);
				
				return listInsertData;
			}
}
