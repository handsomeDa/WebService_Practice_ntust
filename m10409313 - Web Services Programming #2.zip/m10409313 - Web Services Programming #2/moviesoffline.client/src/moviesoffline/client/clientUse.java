package moviesoffline.client;

import java.net.URI;
import java.util.Scanner;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

/**
 * @author M10409313 CHIEN, LI-DA
 * 
 */

public class clientUse {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClientConfig config = new ClientConfig();
		Client client = ClientBuilder.newClient(config);
		WebTarget targetService = client.target(getBaseURI());

		try {
			boolean flag = true;
			boolean flag2 = true;
			int codePress, codePress2;
			String input1, input2, input3, input4, input5, input6, input7, input8, input9, input10;
			String plainAnswer;
			String sqlStr = "";
			String userID = "";

			do {
				Scanner scanner = new Scanner(System.in);

				System.out.println("Please press the code to enter the moviesoffline,\n(1:Login, 0:Exit)");

				codePress = scanner.nextInt();

				switch (codePress) {
				case 0:
					scanner.close();
					System.out.println("Have a nice day!\n");
					flag = false;
					break;

				case 1:
					Scanner scanner1 = new Scanner(System.in);
					System.out.println("Please enter the Username,");
					input1 = scanner1.nextLine();
					System.out.println("Please enter the Password,");
					input2 = scanner1.nextLine();

					plainAnswer = targetService.path("m10409313").path("/login/list/" + input1 + "_" + input2).request()
							.accept(MediaType.APPLICATION_JSON).get(String.class);
					String aa = "[]";
					if (plainAnswer.equals(aa)) {
						System.out.println("Username or Password is Error!");
					} else {
						String infoValue3 = plainAnswer.replace("[{\"user_id\":\"", "");
						userID = infoValue3.replace("\"}]", "");

						do {
							Scanner scanner2 = new Scanner(System.in);
							System.out.println("Please press the code to enter the moviesoffline,\n"
									+ "(1:All-Movie-List, 2:Self-Watch-List, 3:Movie-Search, 4:Insert-Movie-to-Watch, 0:Logout)");
							codePress2 = scanner2.nextInt();
							switch (codePress2) {
							case 0:
								// scanner2.close();
								System.out.println("Logout!!");
								flag2 = false;
								break;

							case 1:
								plainAnswer = targetService.path("m10409313").path("/moviesAll/list").request()
										.accept(MediaType.APPLICATION_JSON).get(String.class);

								String cc = "[]";
								if (plainAnswer.equals(cc)) {
									System.out.println("No Movies!");
								} else {
									String mt1 = plainAnswer.replace("[{", "");
									String mt2 = mt1.replace("},{", "\n");
									String mt3 = mt2.replace("}]", "");
									System.out.println("\n/*All-Movie-List*/\n" + mt3 + "\n/*END*/\n");
								}
								break;

							case 2:
								plainAnswer = targetService.path("m10409313").path("/watch/list/" + userID).request()
										.accept(MediaType.APPLICATION_JSON).get(String.class);

								String dd = "[]";
								if (plainAnswer.equals(dd)) {
									System.out.println("No Watchlist!");
								} else {
									String wt1 = plainAnswer.replace("[{", "");
									String wt2 = wt1.replace("},{", "\n");
									String wt3 = wt2.replace("}]", "");
									System.out.println("\n/*All-Self-Watch-List*/\n" + wt3 + "\n/*END*/\n");
								}
								break;

							case 3:
								Scanner scanner3 = new Scanner(System.in);
								System.out.println("Please enter the Movie ID" + ", or press 'p' ignore,");
								input3 = scanner3.nextLine();
								if (input3.equals("p")) {
									input3 = "";
								} else {
									sqlStr += " AND `movie_id` = " + input3;
								}
								System.out.println("Please enter the Movie Title" + ", or press 'p' ignore,");
								input4 = scanner3.nextLine();
								if (input4.equals("p")) {
									input4 = "";
								} else {
									sqlStr += " AND `title` = " + input4;
								}

								System.out.println("Please enter the Genre ID" + ", or press 'p' ignore,");
								input5 = scanner3.nextLine();
								if (input5.equals("p")) {
									input5 = "";
								} else {
									sqlStr += " AND `genre_id` = " + input5;
								}

								System.out.println("Please enter the Age Rating" + ", or press 'p' ignore,");
								input6 = scanner3.nextLine();
								if (input6.equals("p")) {
									input6 = "";
								} else {
									sqlStr += " AND `age_rating` = " + input6;
								}

								System.out.println("Please enter the Release Date" + ", or press 'p' ignore,");
								input7 = scanner3.nextLine();
								if (input7.equals("p")) {
									input7 = "";
								} else {
									sqlStr += " AND `releaseDate` = " + input7;
								}

								sqlStr = sqlStr.replaceFirst("AND", "");
								System.out.println("\nYour searching requirement:" + sqlStr);

								plainAnswer = targetService.path("m10409313").path("/search/list/" + sqlStr).request()
										.accept(MediaType.APPLICATION_JSON).get(String.class);
								String bb = "[]";
								if (plainAnswer.equals(bb)) {
									System.out.println("No Movies!");
								} else {
									String st1 = plainAnswer.replace("[{", "");
									String st2 = st1.replace("},{", "\n");
									String st3 = st2.replace("}]", "");
									System.out.println("/*All-Search-Movie-Result*/\n" + st3 + "\n/*END*/\n");
								}
								break;

							case 4:
								Scanner scanner4 = new Scanner(System.in);
								System.out.println("Please enter the Movie ID,");
								input8 = scanner4.nextLine();
								System.out.println(
										"Please enter the Movie Status,\n(1:watch list, 2:watched, 3:deleted)");
								input9 = scanner4.nextLine();

								switch (input9) {
								case "1":
									input9 = "watch list";
									break;

								case "2":
									input9 = "watched";
									break;

								case "3":
									input9 = "deleted";
									break;

								default:
									input9 = "";
									System.out.println("Form Error.");
									flag2 = false;
								}

								System.out.println("Please enter the Movie ModifiedDate,\n(e.g. 1992-10-30)");
								input10 = scanner4.nextLine();
								if (input10.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
									System.out.println("Form OK.");
								} else {
									System.out.println("Form Error.");
									flag2 = false;
								}
								String value = userID + "_" + input8 + "_" + input9 + "_" + input10;
								plainAnswer = targetService.path("m10409313").path("/insert/list/" + value).request()
										.accept(MediaType.APPLICATION_JSON).get(String.class);
								
								
								String ee = "[]";
								if (plainAnswer.equals(ee)) {
									System.out.println("No Movies!");
								} else {
									String it1 = plainAnswer.replace("[{", "");
									String it2 = it1.replace("},{", "\n");
									String it3 = it2.replace("}]", "");
									System.out.println("\n/*All-Self-Watch-List*/\n" + it3 + "\n/*END*/\n");
								}
								break;

							default:
								System.out.println("Wrong number!\n");
							}
						} while (flag2 != false);
						break;
					}
				default:
					System.out.println("Wrong number!\n");
				}
			} while (flag != false);
		} catch (Exception ex) {
			System.out.println("Something Wrong! Maybe try again!");
		}
	}

	private static URI getBaseURI() {

		return UriBuilder.fromUri("http://localhost:8080/moviesoffline").build();
	}
}
