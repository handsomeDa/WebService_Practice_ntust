package temperature.convert;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


/**
 * @author M10409313 CHIEN, LI-DA
 * 
 * {@Temperature Formula Source}
 * {@link http://www.csgnetwork.com/temp2conv.html}
 */


@Path("/temperature")
public class temperature {
	double celcius;
	double farenheit;
	double reaumur;	
	double kelvin;
	
	double ccc, fff, rrr, kkk;
	
	//http://localhost:8080/temperature.convert/m10409313/temperature
	@GET
	@Produces(MediaType.TEXT_HTML)	
	public String sayHTMLHELLO(){
		
		return "<html>"
				+ "<head><title>Hello</title></head>"
				+ "<body>"
				+ "<h1>Welcome temperature convert, I'm M10409313 CHIEN, LI-DA!</h1>"
				+ "</body>"
				+ "</html>";
	}		
	
	
	//http://localhost:8080/temperature.convert/m10409313/temperature/celcius-to-all/{inputURI}
	@GET
	@Path("/celcius-to-all/{inputURI}")
	@Produces(MediaType.TEXT_HTML)	
	public String celcius(@PathParam("inputURI") double cc){
		farenheit = c2f(cc);
		reaumur = c2r(cc);
		kelvin = c2k(cc);
		
		return "<html>"
				+ "<head><title>Celcius-to-All</title></head>"
				+ "<body>"
				+ "<h1><p><font color='#ff0000'>"+cc+"</font> Celcius is equal to <font color='#ff0000'>"+farenheit+"</font> Farenheit</p></h1>"
				+ "<h1><p><font color='#ff0000'>"+cc+"</font> Celcius is equal to <font color='#ff0000'>"+reaumur+"</font> Reaumur</p></h1>"
				+ "<h1><p><font color='#ff0000'>"+cc+"</font> Celcius is equal to <font color='#ff0000'>"+kelvin+"</font> Kelvin</p></h1>"
				+ "</body>"
				+ "</html>";
	}
	
	@GET
	@Path("/celcius-to-all/{inputURI}")
	@Produces(MediaType.TEXT_PLAIN)	
	public String celciusT(@PathParam("inputURI") double cc){
		farenheit = c2f(cc);
		reaumur = c2r(cc);
		kelvin = c2k(cc);
		
		return cc+" Celcius is equal to "+farenheit+" Farenheit.\n"
				+ cc+" Celcius is equal to "+reaumur+" Reaumur.\n"
				+ cc+" Celcius is equal to "+kelvin+" Kelvin.\n";
	}
	
	
	//http://localhost:8080/temperature.convert/m10409313/temperature/farenheit-to-all/{inputURI}
	@GET
	@Path("/farenheit-to-all/{inputURI}")
	@Produces(MediaType.TEXT_HTML)	
	public String farenheit(@PathParam("inputURI") double ff){
		
		celcius = f2c(ff);
		reaumur = f2r(ff);
		kelvin = f2k(ff);
		
		return "<html>"
				+ "<head><title>Farenheit-to-All</title></head>"
				+ "<body>"
				+ "<h1><p><font color='#ff0000'>"+ff+"</font> Farenheit is equal to <font color='#ff0000'>"+celcius+"</font> Celsius</p></h1>"
				+ "<h1><p><font color='#ff0000'>"+ff+"</font> Farenheit is equal to <font color='#ff0000'>"+reaumur+"</font> Reaumur</p></h1>"
				+ "<h1><p><font color='#ff0000'>"+ff+"</font> Farenheit is equal to <font color='#ff0000'>"+kelvin+"</font> Kelvin</p></h1>"
				+ "</body>"
				+ "</html>";
	}
	
	@GET
	@Path("/farenheit-to-all/{inputURI}")
	@Produces(MediaType.TEXT_PLAIN)	
	public String farenheitT(@PathParam("inputURI") double ff){
		
		celcius = f2c(ff);
		reaumur = f2r(ff);
		kelvin = f2k(ff);
		
		return ff+" Farenheit is equal to "+celcius+" Celcius.\n"
				+ ff+" Farenheit is equal to "+reaumur+" Reaumur.\n"
				+ ff+" Farenheit is equal to "+kelvin+" Kelvin.\n";
	}
	
	
	//http://localhost:8080/temperature.convert/m10409313/temperature/reaumur-to-all/{inputURI}
	@GET
	@Path("/reaumur-to-all/{inputURI}")
	@Produces(MediaType.TEXT_HTML)	
	public String reaumur(@PathParam("inputURI") double rr){
		
		celcius = r2c(rr);
		farenheit = r2f(rr);
		kelvin = r2k(rr);
		
		return "<html>"
		+ "<head><title>Reaumur-to-All</title></head>"
		+ "<body>"
		+ "<h1><p><font color='#ff0000'>"+rr+"</font> Reaumur is equal to <font color='#ff0000'>"+celcius+"</font> Celcius</p></h1>"
		+ "<h1><p><font color='#ff0000'>"+rr+"</font> Reaumur is equal to <font color='#ff0000'>"+farenheit+"</font> Farenheit</p></h1>"
		+ "<h1><p><font color='#ff0000'>"+rr+"</font> Reaumur is equal to <font color='#ff0000'>"+kelvin+"</font> Kelvin</p></h1>"
		+ "</body>"
		+ "</html>";
	}
	
	@GET
	@Path("/reaumur-to-all/{inputURI}")
	@Produces(MediaType.TEXT_PLAIN)	
	public String reaumurT(@PathParam("inputURI") double rr){
		
		celcius = r2c(rr);
		farenheit = r2f(rr);
		kelvin = r2k(rr);
		
		return rr+" Reaumur is equal to "+celcius+" Celcius.\n"
		+ rr+" Reaumur is equal to "+farenheit+" Farenheit.\n"
		+ rr+" Reaumur is equal to "+kelvin+" Kelvin.\n";
	}
	
	
	//http://localhost:8080/temperature.convert/m10409313/temperature/kelvin-to-all/{inputURI}
	@GET
	@Path("/kelvin-to-all/{inputURI}")
	@Produces(MediaType.TEXT_HTML)	
	public String kelvin(@PathParam("inputURI") double kk){
		
		celcius = k2c(kk);
		farenheit = k2f(kk);
		reaumur = k2r(kk);
		
		return "<html>"
		+ "<head><title>Kelvin-to-All</title></head>"
		+ "<body>"
		+ "<h1><p><font color='#ff0000'>"+kk+"</font> Kelvin is equal to <font color='#ff0000'>"+celcius+"</font> Celcius</p></h1>"
		+ "<h1><p><font color='#ff0000'>"+kk+"</font> Kelvin is equal to <font color='#ff0000'>"+farenheit+"</font> Farenheit</p></h1>"
		+ "<h1><p><font color='#ff0000'>"+kk+"</font> Kelvin is equal to <font color='#ff0000'>"+reaumur+"</font> Reaumur</p></h1>"
		+ "</body>"
		+ "</html>";
	}
	
	@GET
	@Path("/kelvin-to-all/{inputURI}")
	@Produces(MediaType.TEXT_PLAIN)	
	public String kelvinT(@PathParam("inputURI") double kk){
		
		celcius = k2c(kk);
		farenheit = k2f(kk);
		reaumur = k2r(kk);
		
		return kk+" Kelvin is equal to "+celcius+" Celcius.\n"
		+ kk+" Kelvin is equal to "+farenheit+" Farenheit.\n"
		+ kk+" Kelvin is equal to "+reaumur+" Reaumur.\n";
	}
	
	
	
	//function Celcius2All
	public double c2f(double input){
		fff = input * 1.8 + 32;
		return fff;
	}	
	public double c2r(double input){
		rrr = input * 0.8;
		return rrr;
	}	
	public double c2k(double input){
		kkk = input + 273.15;
		return kkk;
	}
	
	
	//function Farenheit2All
	public double f2c(double input){
		ccc = (input - 32) / 1.8;
		return ccc;
	}
	public double f2r(double input){
		rrr = (input - 32) / 2.25;
		return rrr;
	}
	public double f2k(double input){
		kkk = (input + 459.67) / 1.8;
		return kkk;
	}
	
	
	//function Reaumur2All
	public double r2c(double input){
		ccc = input * 1.25;
		return ccc;
	}
	public double r2f(double input){
		fff = input * 2.25 + 32;
		return fff;
	}
	public double r2k(double input){
		kkk = input * 1.25 + 273.15;
		return kkk;
	}
	
	
	//function Kelvin2All
	public double k2c(double input){
		ccc = input - 273.15;
		return ccc;
	}
	public double k2f(double input){
		fff = input * 1.8 - 459.67;
		return fff;
	}
	public double k2r(double input){
		rrr = (input - 273.15) * 0.8;
		return rrr;
	}
}


