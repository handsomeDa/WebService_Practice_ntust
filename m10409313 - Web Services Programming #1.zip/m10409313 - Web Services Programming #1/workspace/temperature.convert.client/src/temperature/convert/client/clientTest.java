package temperature.convert.client;

import java.net.URI;
import java.util.Scanner;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;


/**
 * @author M10409313 CHIEN, LI-DA
 * 
 * {@Temperature Formula Source}
 * {@link http://www.csgnetwork.com/temp2conv.html}
 */


public class clientTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClientConfig config = new ClientConfig();
		Client client = ClientBuilder.newClient(config);
		WebTarget targetService = client.target(getBaseURI());
		
				
		//String plainAnswer = targetService.path("m10409313").path("temperature").request().accept(MediaType.TEXT_PLAIN).get(String.class);
		//System.out.println(plainAnswer);
		//String htmlAnswer = targetService.path("m10409313").path("temperature").request().accept(MediaType.TEXT_HTML).get(String.class);
		//System.out.println(htmlAnswer);
		//String xmlAnswer = targetService.path("m10409313").path("temperature").request().accept(MediaType.TEXT_XML).get(String.class);
		//System.out.println(xmlAnswer);
		
		try{
			boolean flag = true;
			int codePress;
			String input;
			String plainAnswer;
			
			
			do{
				Scanner scanner = new Scanner(System.in);
		        
		        System.out.println("Please press the code to enter the temperature.convert,"
		        		+ " 1:Celcius-to-All, 2:Farenheit-to-all, 3:Reaumur-to-all, 4:Kelvin-to-all, 0:Exit");		
				
		        codePress = scanner.nextInt();
		        
		        
		        switch(codePress){
		        	case 0:
		        		scanner.close();
		        		System.out.println("Have a nice day!");
		        		flag = false;
		        		break;
		        		
		        	case 1:
		        		Scanner scanner1 = new Scanner(System.in);
		        		System.out.println("Please enter the Celcius temperature to convert,");
		        		input = scanner1.nextLine();
		        		plainAnswer = targetService.path("m10409313").path("/temperature/celcius-to-all/"+input).request().accept(MediaType.TEXT_PLAIN).get(String.class);
		        		System.out.println(plainAnswer);
		        		break;
		        		
		        	case 2:
		        		Scanner scanner2 = new Scanner(System.in);
		        		System.out.println("Please enter the Farenheit temperature to convert,");
		        		input = scanner2.nextLine();
		        		plainAnswer = targetService.path("m10409313").path("/temperature/farenheit-to-all/"+input).request().accept(MediaType.TEXT_PLAIN).get(String.class);
		        		System.out.println(plainAnswer);
		        		break;
		        		
		        	case 3:
		        		Scanner scanner3 = new Scanner(System.in);
		        		System.out.println("Please enter the Reaumur temperature to convert,");
		        		input = scanner3.nextLine();
		        		plainAnswer = targetService.path("m10409313").path("/temperature/reaumur-to-all/"+input).request().accept(MediaType.TEXT_PLAIN).get(String.class);
		        		System.out.println(plainAnswer);
		        		break;
		        		
		        	case 4:
		        		Scanner scanner4 = new Scanner(System.in);
		        		System.out.println("Please enter the Kelvin temperature to convert,");
		        		input = scanner4.nextLine();
		        		plainAnswer = targetService.path("m10409313").path("/temperature/kelvin-to-all/"+input).request().accept(MediaType.TEXT_PLAIN).get(String.class);
		        		System.out.println(plainAnswer);
		        		break;
		        	default:
		        		System.out.println("Wrong number!");        
		        }
			}while(flag != false);
		}
		catch(Exception ex){
			System.out.println("Something Wrong! Maybe try again!");
		}        
	}
	
	
	private static URI getBaseURI(){
		
		return UriBuilder.fromUri("http://localhost:8080/temperature.convert").build();
	}

}
